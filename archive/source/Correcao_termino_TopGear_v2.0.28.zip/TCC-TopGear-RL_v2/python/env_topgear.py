from __future__ import annotations

from pathlib import Path
from typing import Any

import gymnasium as gym
import numpy as np
from gymnasium import spaces

from protocol import BridgeClient, BridgeState, ProtocolError
from reward import RewardWeights, calculate_reward
from telemetry import OBSERVATION_NAMES, ObservationBuilder, Telemetry
from topgear_config import ACTION_NAMES, ProjectConfig


class TopGearEnv(gym.Env[np.ndarray, int]):
    """Ambiente síncrono para Top Gear (USA) no BizHawk.

    Cada step envia uma sequência, o Lua aplica a ação por uma quantidade fixa
    de frames e responde com o mesmo ack. Treinos são bloqueados enquanto o
    perfil de memória/controles não estiver marcado como validado.
    """

    metadata = {"render_modes": []}

    def __init__(
        self,
        project_dir: str | Path | None = None,
        *,
        require_validated: bool = True,
    ) -> None:
        super().__init__()
        self.config = ProjectConfig.load(project_dir)
        self.require_validated = bool(require_validated)
        if self.require_validated:
            self.config.assert_training_ready()

        self.action_space = spaces.Discrete(self.config.action_count)
        self.observation_space = spaces.Box(
            low=ObservationBuilder.low(),
            high=ObservationBuilder.high(),
            dtype=np.float32,
        )

        self.bridge = BridgeClient(self.config)
        host, port = self.bridge.address
        print(f"Servidor da ponte pronto em {host}:{port}; aguardando BizHawk/Lua...")
        try:
            ready = self.bridge.wait_ready()
        except Exception:
            self.bridge.close()
            raise
        if self.require_validated:
            Telemetry.from_fields(ready.fields).assert_runtime_ready()

        self.observations = ObservationBuilder(self.config)
        self.weights = RewardWeights.from_config(self.config)
        self.max_steps = self.config.integer("episode", "max_steps")
        self.no_progress_limit = self.config.integer(
            "episode", "no_progress_steps"
        )
        self.progress_epsilon = self.config.integer("episode", "progress_epsilon")

        self._previous: Telemetry | None = None
        self._step_count = 0
        self._no_progress_count = 0
        self._collision_count = 0
        self._overtake_count = 0
        self._closed = False

    @property
    def observation_names(self) -> tuple[str, ...]:
        return OBSERVATION_NAMES

    def _telemetry(self, state: BridgeState) -> Telemetry:
        telemetry = Telemetry.from_fields(state.fields)
        if self.require_validated:
            telemetry.assert_runtime_ready()
        return telemetry

    def _info(
        self,
        telemetry: Telemetry,
        *,
        reward_components: dict[str, float] | None = None,
        collision_event: bool = False,
        termination_reason: str = "",
    ) -> dict[str, Any]:
        info: dict[str, Any] = {
            "frame": telemetry.frame,
            "speed": telemetry.speed,
            "lateral": telemetry.lateral,
            "progress": telemetry.progress,
            "progress_total": telemetry.absolute_progress
            if telemetry.absolute_progress is not None
            else -1,
            "lap": telemetry.lap,
            "rank": telemetry.rank,
            "final_rank": telemetry.final_rank,
            "race_ended": int(bool(telemetry.finished)),
            "finished": int(telemetry.race_completed),
            "race_completed": int(telemetry.race_completed),
            "total_laps": telemetry.total_laps,
            "track_length": telemetry.track_length,
            "is_first": int(telemetry.race_completed and telemetry.final_rank == 0),
            "collision": telemetry.collision,
            "collision_event": int(collision_event),
            "collisions_total": self._collision_count,
            "overtakes_total": self._overtake_count,
            "offtrack": telemetry.offtrack,
            "surface_raw": telemetry.surface_raw,
            "surface_unknown": telemetry.surface_unknown,
            "surface_state": telemetry.surface_state,
            "surface_direction": telemetry.surface_direction,
            "nitro": telemetry.nitro,
            "nitro_raw": telemetry.nitro_raw,
            "turbo_active": telemetry.turbo_active,
            "curve_progress": telemetry.curve_progress,
            "curve_current": telemetry.curve_current,
            "curve_ahead_512": telemetry.curve_ahead_512,
            "curve_ahead_1024": telemetry.curve_ahead_1024,
            "curve_ahead_2048": telemetry.curve_ahead_2048,
            "nearest_valid": telemetry.nearest_valid,
            "nearest_id": telemetry.nearest_id,
            "nearest_distance": telemetry.nearest_distance,
            "opponent_count": telemetry.opponent_count,
            "termination_reason": termination_reason,
        }
        for key, value in (reward_components or {}).items():
            info[f"reward_{key}"] = float(value)
        return info

    def reset(
        self,
        *,
        seed: int | None = None,
        options: dict[str, Any] | None = None,
    ) -> tuple[np.ndarray, dict[str, Any]]:
        super().reset(seed=seed)
        del options
        self._step_count = 0
        self._no_progress_count = 0
        self._collision_count = 0
        self._overtake_count = 0

        telemetry = self._telemetry(self.bridge.reset())
        observation = self.observations.reset(telemetry)
        self._previous = telemetry
        return observation, self._info(telemetry)

    def step(
        self, action: int
    ) -> tuple[np.ndarray, float, bool, bool, dict[str, Any]]:
        if self._previous is None:
            raise ProtocolError("Chame env.reset() antes de env.step()")
        action_id = int(action)
        if not self.action_space.contains(action_id):
            raise ValueError(
                f"Ação {action_id} fora de Discrete({self.action_space.n})"
            )

        self._step_count += 1
        current = self._telemetry(self.bridge.step(action_id))
        observation = self.observations.build(current)
        result = calculate_reward(self._previous, current, self.weights)
        components = dict(result.components)
        reward = result.total
        if result.components["invalid_progress_jump"]:
            raise ProtocolError(
                "Salto de progresso fisicamente implausível; transição recusada para "
                "não contaminar o rollout"
            )

        if result.progress_delta > self.progress_epsilon:
            self._no_progress_count = 0
        else:
            self._no_progress_count += 1
        if result.collision_event:
            self._collision_count += result.collision_count
        self._overtake_count += result.overtake_count

        failed_no_progress = (
            not current.finished
            and self._no_progress_count >= self.no_progress_limit
        )
        if failed_no_progress:
            components["failure"] = -self.weights.failure
            reward -= self.weights.failure

        terminated = bool(current.finished or failed_no_progress)
        truncated = bool(not terminated and self._step_count >= self.max_steps)
        if truncated:
            components["time_limit"] = -self.weights.failure
            reward -= self.weights.failure
        if current.finished:
            # Inclui o tempo esgotado observado pelo usuario; sem um sinal de
            # timer validado, nao atribuir causa exata a todos os encerramentos.
            reason = "finished" if current.race_completed else "race_ended_incomplete"
        elif failed_no_progress:
            reason = "no_progress"
        elif truncated:
            reason = "time_limit"
        else:
            reason = ""

        self._previous = current
        info = self._info(
            current,
            reward_components=components,
            collision_event=result.collision_event,
            termination_reason=reason,
        )
        info["action_name"] = ACTION_NAMES[action_id]
        return observation, float(reward), terminated, truncated, info

    def close(self) -> None:
        if not self._closed:
            self.bridge.close()
            self._closed = True
        super().close()
