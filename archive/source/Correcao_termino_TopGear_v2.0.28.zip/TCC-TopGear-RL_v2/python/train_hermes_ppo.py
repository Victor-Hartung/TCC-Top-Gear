from __future__ import annotations

import argparse
import json
import shutil
from datetime import datetime
from pathlib import Path

from stable_baselines3 import PPO
from stable_baselines3.common.callbacks import CheckpointCallback
from stable_baselines3.common.env_checker import check_env
from stable_baselines3.common.monitor import Monitor

from callbacks import RaceMetricsCallback
from env_topgear import TopGearEnv
from telemetry import OBSERVATION_SCHEMA_VERSION
from topgear_config import ProjectConfig


def arguments() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Treina PPO no Top Gear via BizHawk")
    parser.add_argument("--timesteps", type=int, default=100_000)
    parser.add_argument("--seed", type=int, default=42)
    parser.add_argument("--checkpoint-every", type=int, default=25_000)
    parser.add_argument("--resume", type=Path)
    parser.add_argument("--skip-env-check", action="store_true")
    return parser.parse_args()


def main() -> None:
    args = arguments()
    if args.timesteps < 1:
        raise ValueError("--timesteps deve ser >= 1")
    if args.checkpoint_every < 1:
        raise ValueError("--checkpoint-every deve ser >= 1")
    if args.resume is not None and not args.resume.is_file():
        raise FileNotFoundError(f"Modelo de retomada não encontrado: {args.resume}")

    project_dir = Path(__file__).resolve().parents[1]
    config = ProjectConfig.load(project_dir)
    config.assert_training_ready()

    raw_env = TopGearEnv(project_dir=project_dir, require_validated=True)
    try:
        if not args.skip_env_check:
            print("Executando check_env; o BizHawk fará alguns resets/steps...")
            check_env(raw_env, warn=True, skip_render_check=True)
    except Exception:
        raw_env.close()
        raise

    run_name = "hermes-rl-ppo_" + datetime.now().strftime("%Y%m%d_%H%M%S")
    run_dir = project_dir / "runs" / run_name
    model_dir = project_dir / "models" / run_name
    run_dir.mkdir(parents=True, exist_ok=False)
    model_dir.mkdir(parents=True, exist_ok=False)
    shutil.copy2(config.path, run_dir / "game_profile.ini")
    (run_dir / "run_config.json").write_text(
        json.dumps(
            {
                "run_name": run_name,
                "timesteps_requested": args.timesteps,
                "seed": args.seed,
                "checkpoint_every": args.checkpoint_every,
                "resume": str(args.resume.resolve()) if args.resume else None,
                "observation_schema": OBSERVATION_SCHEMA_VERSION,
                "reward_semantics": "completion_requires_final_rank_and_total_laps_v1",
                "action_count": config.action_count,
                "frame_repeat": config.frame_repeat,
                "algorithm": "PPO",
                "policy": "MlpPolicy",
                "network": {
                    "policy_layers": [64, 64],
                    "value_layers": [64, 64],
                    "activation": "Tanh",
                },
                "ppo": {
                    "n_steps": 2048,
                    "batch_size": 64,
                    "gamma": 0.99,
                    "gae_lambda": 0.95,
                    "n_epochs": 10,
                    "clip_range": 0.2,
                    "learning_rate": 3e-4,
                    "ent_coef": 0.0,
                    "vf_coef": 0.5,
                    "max_grad_norm": 0.5,
                },
            },
            indent=2,
            ensure_ascii=False,
        ),
        encoding="utf-8",
    )

    info_keys = (
        "race_ended",
        "race_completed",
        "lap",
        "total_laps",
        "progress",
        "frame",
        "rank",
        "final_rank",
        "is_first",
        "collisions_total",
        "overtakes_total",
        "termination_reason",
    )
    env = Monitor(raw_env, filename=str(run_dir / "monitor.csv"), info_keywords=info_keys)
    checkpoint = CheckpointCallback(
        save_freq=max(1, args.checkpoint_every),
        save_path=str(model_dir),
        name_prefix="checkpoint",
        save_replay_buffer=False,
        save_vecnormalize=False,
    )
    race_metrics = RaceMetricsCallback(model_dir=model_dir, verbose=1)

    try:
        if args.resume:
            model = PPO.load(args.resume, env=env, device="auto")
            reset_num_timesteps = False
        else:
            model = PPO(
                policy="MlpPolicy",
                env=env,
                verbose=1,
                tensorboard_log=str(run_dir),
                n_steps=2048,
                batch_size=64,
                gamma=0.99,
                gae_lambda=0.95,
                n_epochs=10,
                clip_range=0.2,
                learning_rate=3e-4,
                ent_coef=0.0,
                vf_coef=0.5,
                max_grad_norm=0.5,
                policy_kwargs={"net_arch": {"pi": [64, 64], "vf": [64, 64]}},
                seed=args.seed,
                device="auto",
            )
            reset_num_timesteps = True

        try:
            model.learn(
                total_timesteps=args.timesteps,
                callback=[checkpoint, race_metrics],
                tb_log_name="PPO",
                reset_num_timesteps=reset_num_timesteps,
            )
        except KeyboardInterrupt:
            interrupted = model_dir / f"interrupted_{model.num_timesteps}_steps"
            model.save(str(interrupted))
            print(f"Treino interrompido; checkpoint salvo em {interrupted}.zip")
            return
        except Exception:
            failed = model_dir / f"failed_{model.num_timesteps}_steps"
            model.save(str(failed))
            print(f"Falha durante o treino; snapshot preservado em {failed}.zip")
            raise
    finally:
        env.close()

    final_path = model_dir / f"final_{model.num_timesteps}_steps"
    model.save(str(final_path))
    print(f"Treino concluído. Modelo final: {final_path}.zip")


if __name__ == "__main__":
    main()
