from __future__ import annotations

from pathlib import Path
from typing import Any

from stable_baselines3.common.callbacks import BaseCallback


class RaceMetricsCallback(BaseCallback):
    """Registra métricas da corrida e salva o melhor episódio sem sobrescrever runs."""

    def __init__(self, model_dir: Path, verbose: int = 0):
        super().__init__(verbose=verbose)
        self.model_dir = model_dir
        self.best_score: tuple[int, int, float] | None = None
        self.episodes = 0
        self.wins = 0

    def _on_step(self) -> bool:
        infos: list[dict[str, Any]] = self.locals.get("infos", [])
        dones = self.locals.get("dones", [])
        for index, info in enumerate(infos):
            if "rank" in info:
                self.logger.record("race/current_rank", float(info["rank"]))
            if "collisions_total" in info:
                self.logger.record(
                    "race/collisions_current_episode",
                    float(info["collisions_total"]),
                )
            for key, value in info.items():
                if key.startswith("reward_") and isinstance(value, (int, float)):
                    self.logger.record(f"reward_components/{key[7:]}", float(value))

            if index >= len(dones) or not dones[index]:
                continue
            self.episodes += 1
            final_rank = int(info.get("final_rank", -1))
            finished = int(info.get("finished", 0))
            win = int(info.get("is_first", 0))
            self.wins += win
            episode_info = info.get("episode", {})
            episode_reward = float(episode_info.get("r", float("-inf")))
            rank_score = -final_rank if finished and final_rank >= 0 else -100
            score = (finished, rank_score, episode_reward)

            self.logger.record("race/episodes", self.episodes)
            self.logger.record("race/win_rate", self.wins / self.episodes)
            self.logger.record("race/final_rank", float(final_rank))
            self.logger.record("race/completed", finished)
            self.logger.record("race/ended_incomplete", int(
                bool(info.get("race_ended", 0)) and not finished
            ))
            self.logger.record(
                "race/overtakes", float(info.get("overtakes_total", 0))
            )
            self.logger.record(
                "race/collisions", float(info.get("collisions_total", 0))
            )

            if self.best_score is None or score > self.best_score:
                self.best_score = score
                self.model.save(str(self.model_dir / "best_model"))
                if self.verbose:
                    print(
                        "Novo melhor episódio: "
                        f"finished={finished}, rank={final_rank}, reward={episode_reward:.3f}"
                    )
        return True
