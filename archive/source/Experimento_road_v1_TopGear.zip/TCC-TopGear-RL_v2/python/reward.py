from __future__ import annotations

from dataclasses import dataclass, replace

from telemetry import Telemetry
from topgear_config import ProjectConfig


@dataclass(frozen=True)
class RewardWeights:
    progress: float
    rank_delta: float
    collision: float
    offtrack: float
    finish: float
    finish_rank: float
    first_place: float
    failure: float
    max_progress_fraction: float
    road_progress_only: bool = False
    idle_penalty: float = 0.0
    idle_grace_steps: int = 15

    @classmethod
    def from_config(cls, config: ProjectConfig) -> "RewardWeights":
        number = lambda key: config.number("reward", key)
        return cls(
            progress=number("progress_weight"),
            rank_delta=number("rank_delta_weight"),
            collision=number("collision_penalty"),
            offtrack=number("offtrack_penalty"),
            finish=number("finish_bonus"),
            finish_rank=number("finish_rank_bonus"),
            first_place=number("first_place_bonus"),
            failure=number("failure_penalty"),
            max_progress_fraction=number("max_progress_fraction_per_step"),
        )


@dataclass(frozen=True)
class RewardResult:
    total: float
    components: dict[str, float]
    progress_delta: int
    collision_event: bool
    collision_count: int
    overtake_count: int
    finish_event: bool


def road_reward_v1(weights: RewardWeights) -> RewardWeights:
    """Experimento opt-in; nao altera INI nem controles."""
    return replace(weights, progress=20.0, road_progress_only=True,
                   idle_penalty=0.02, idle_grace_steps=15)


@dataclass
class IdleTracker:
    consecutive_steps: int = 0

    def penalty(self, previous: Telemetry, current: Telemetry,
                progress_delta: int, weights: RewardWeights) -> float:
        stopped = (not current.finished and current.speed == 0
                   and progress_delta <= 0 and not current.collision
                   and current.collision_events <= previous.collision_events)
        self.consecutive_steps = self.consecutive_steps + 1 if stopped else 0
        if self.consecutive_steps > weights.idle_grace_steps:
            return -weights.idle_penalty
        return 0.0


def calculate_reward(
    previous: Telemetry,
    current: Telemetry,
    weights: RewardWeights,
) -> RewardResult:
    components = {
        "progress": 0.0,
        "rank_delta": 0.0,
        "collision": 0.0,
        "offtrack": 0.0,
        "finish": 0.0,
        "finish_rank": 0.0,
        "first_place": 0.0,
        "invalid_progress_jump": 0.0,
    }

    progress_delta = 0
    if (
        previous.lap >= 0
        and current.lap >= 0
        and current.track_length > 0
    ):
        # O contador de volta apresentou um transiente 0->1->0 antes da linha.
        # O delta modular do progresso ignora esse pulso e trata o wrap real.
        progress_delta = current.progress - previous.progress
        half_track = current.track_length / 2
        if progress_delta < -half_track:
            progress_delta += current.track_length
        elif progress_delta > half_track:
            progress_delta -= current.track_length
        max_delta = current.track_length * weights.max_progress_fraction
        if abs(progress_delta) <= max_delta:
            components["progress"] = (
                progress_delta / current.track_length
            ) * weights.progress
        else:
            components["invalid_progress_jump"] = 1.0

    # Recuo continua negativo inclusive fora da pista: impede ciclos de ida/volta.
    if (weights.road_progress_only and progress_delta > 0
            and (previous.offtrack or current.offtrack)):
        components["progress"] = 0.0

    rank_delta = 0
    if 0 <= previous.rank <= 19 and 0 <= current.rank <= 19:
        rank_delta = previous.rank - current.rank
        components["rank_delta"] = rank_delta * weights.rank_delta
        # A própria melhora de rank já recompensa a ultrapassagem. Um bônus
        # apenas na subida tornaria perder e recuperar a mesma posição lucrativo.

    collision_count = max(current.collision_events - previous.collision_events, 0)
    collision_event = collision_count > 0
    if collision_event:
        components["collision"] = -weights.collision * collision_count
    if current.offtrack:
        components["offtrack"] = -weights.offtrack

    finish_event = bool(current.race_completed and not previous.race_completed)
    if finish_event:
        components["finish"] = weights.finish
        if 0 <= current.final_rank <= 19:
            quality = (19 - current.final_rank) / 19.0
            components["finish_rank"] = quality * weights.finish_rank
            if current.final_rank == 0:
                components["first_place"] = weights.first_place

    # invalid_progress_jump é telemetria diagnóstica, não recompensa.
    total = float(
        sum(value for key, value in components.items() if key != "invalid_progress_jump")
    )
    return RewardResult(
        total=total,
        components=components,
        progress_delta=progress_delta,
        collision_event=collision_event,
        collision_count=collision_count,
        overtake_count=max(rank_delta, 0),
        finish_event=finish_event,
    )
